<?php
/**
 * moved to toolset-common
 * ../toolset/toolset-common/classes/validate.php
 */
require_once dirname( __FILE__ ) . '/../toolset/toolset-common/classes/validate.php';
