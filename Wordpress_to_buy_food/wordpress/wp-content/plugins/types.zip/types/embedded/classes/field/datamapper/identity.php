<?php

/**
 * Identity data mapper. Does nothing.
 *
 * @since 1.9
 */
class WPCF_Field_DataMapper_Identity extends WPCF_Field_DataMapper_Abstract {

	// Nothing to do here.

}